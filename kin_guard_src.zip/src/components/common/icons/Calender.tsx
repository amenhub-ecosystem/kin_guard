import * as React from "react";

type Props = React.SVGProps<SVGSVGElement> & { size?: number | string; color?: string; };

export function Calender({ size, width, height, color = "white", ...props }: Props) {
  return (
    <svg viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg" width={size ?? width ?? 24} height={size ?? height ?? 24} {...props}>
    <path d="M5 0C5.69141 0 6.25 0.558594 6.25 1.25V2.5H11.25V1.25C11.25 0.558594 11.8086 0 12.5 0C13.1914 0 13.75 0.558594 13.75 1.25V2.5H15.625C16.6602 2.5 17.5 3.33984 17.5 4.375V6.25H0V4.375C0 3.33984 0.839844 2.5 1.875 2.5H3.75V1.25C3.75 0.558594 4.30859 0 5 0ZM0 7.5H17.5V18.125C17.5 19.1602 16.6602 20 15.625 20H1.875C0.839844 20 0 19.1602 0 18.125V7.5ZM12.8516 11.9141C13.2188 11.5469 13.2188 10.9531 12.8516 10.5898C12.4844 10.2266 11.8906 10.2227 11.5273 10.5898L7.81641 14.3008L5.98047 12.4648C5.61328 12.0977 5.01953 12.0977 4.65625 12.4648C4.29297 12.832 4.28906 13.4258 4.65625 13.7891L7.15625 16.2891C7.52344 16.6562 8.11719 16.6562 8.48047 16.2891L12.8516 11.9141Z" fill={color}/>
    </svg>
  );
}

export default Calender;
