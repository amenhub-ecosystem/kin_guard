import * as React from "react";

type Props = React.SVGProps<SVGSVGElement> & { size?: number | string; color?: string };

export function CalenderSolid({ size, width, height, color = "#64748B", ...props }: Props) {
  return (
    <svg viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg" width={size ?? width ?? 24} height={size ?? height ?? 24} {...props}>
    <path d="M4 0C4.55312 0 5 0.446875 5 1V2H9V1C9 0.446875 9.44687 0 10 0C10.5531 0 11 0.446875 11 1V2H12.5C13.3281 2 14 2.67188 14 3.5V5H0V3.5C0 2.67188 0.671875 2 1.5 2H3V1C3 0.446875 3.44688 0 4 0ZM0 6H14V14.5C14 15.3281 13.3281 16 12.5 16H1.5C0.671875 16 0 15.3281 0 14.5V6ZM2.5 8C2.225 8 2 8.225 2 8.5V11.5C2 11.775 2.225 12 2.5 12H5.5C5.775 12 6 11.775 6 11.5V8.5C6 8.225 5.775 8 5.5 8H2.5Z" fill={color}/>
    </svg>
  );
}

export default CalenderSolid;
