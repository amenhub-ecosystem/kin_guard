import * as React from "react";

type Props = React.SVGProps<SVGSVGElement> & { size?: number | string; color?: string; };

export function Check({ size, width, height, color = "#FE706D", ...props }: Props) {
  return (
    <svg viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" width={size ?? width ?? 24} height={size ?? height ?? 24} {...props}>
    <path d="M13.7086 0.292969C14.0992 0.683594 14.0992 1.31797 13.7086 1.70859L5.70859 9.70859C5.31797 10.0992 4.68359 10.0992 4.29297 9.70859L0.292969 5.70859C-0.0976562 5.31797 -0.0976562 4.68359 0.292969 4.29297C0.683594 3.90234 1.31797 3.90234 1.70859 4.29297L5.00234 7.58359L12.2961 0.292969C12.6867 -0.0976562 13.3211 -0.0976562 13.7117 0.292969H13.7086Z" fill={color}/>
    </svg>
  );
}

export default Check;
