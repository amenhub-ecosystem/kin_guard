import * as React from "react";

type Props = React.SVGProps<SVGSVGElement> & { size?: number | string; color?: string };

export function Bolt({ size, width, height, color = "#003665", ...props }: Props) {
  return (
    <svg viewBox="0 0 12 16" fill="none" xmlns="http://www.w3.org/2000/svg" width={size ?? width ?? 24} height={size ?? height ?? 24} {...props}>
    <path d="M9.92004 1.39403C10.1044 0.965908 9.96692 0.465908 9.58879 0.190908C9.21067 -0.0840923 8.69504 -0.0590923 8.34192 0.247158L0.34192 7.24716C0.0294204 7.52216 -0.0830796 7.96278 0.0637954 8.35028C0.21067 8.73778 0.58567 9.00028 1.0013 9.00028H4.48567L2.08255 14.6065C1.89817 15.0347 2.03567 15.5347 2.4138 15.8097C2.79192 16.0847 3.30755 16.0597 3.66067 15.7534L11.6607 8.75341C11.9732 8.47841 12.0857 8.03778 11.9388 7.65028C11.7919 7.26278 11.42 7.00341 11.0013 7.00341H7.51692L9.92004 1.39403Z" fill={color}/>
    </svg>
  );
}

export default Bolt;
