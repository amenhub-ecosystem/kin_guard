import * as React from "react";

type Props = React.SVGProps<SVGSVGElement> & { size?: number | string; color?: string };

export function Camera({ size, width, height, color = "#9CA3AF", ...props }: Props) {
  return (
    <svg viewBox="0 0 24 21" fill="none" xmlns="http://www.w3.org/2000/svg" width={size ?? width ?? 24} height={size ?? height ?? 24} {...props}>
    <path d="M6.98906 1.5375L6.50156 3H3C1.34531 3 0 4.34531 0 6V18C0 19.6547 1.34531 21 3 21H21C22.6547 21 24 19.6547 24 18V6C24 4.34531 22.6547 3 21 3H17.4984L17.0109 1.5375C16.7062 0.61875 15.8484 0 14.8781 0H9.12188C8.15156 0 7.29375 0.61875 6.98906 1.5375ZM12 7.5C13.1935 7.5 14.3381 7.97411 15.182 8.81802C16.0259 9.66193 16.5 10.8065 16.5 12C16.5 13.1935 16.0259 14.3381 15.182 15.182C14.3381 16.0259 13.1935 16.5 12 16.5C10.8065 16.5 9.66193 16.0259 8.81802 15.182C7.97411 14.3381 7.5 13.1935 7.5 12C7.5 10.8065 7.97411 9.66193 8.81802 8.81802C9.66193 7.97411 10.8065 7.5 12 7.5Z" fill={color}/>
    </svg>
  );
}

export default Camera;
