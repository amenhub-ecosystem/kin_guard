import * as React from "react";

type Props = React.SVGProps<SVGSVGElement> & { size?: number | string; color?: string };

export function CreditCard({ size, width, height, color = "#6B7280", ...props }: Props) {
  return (
    <svg viewBox="0 0 18 14" fill="none" xmlns="http://www.w3.org/2000/svg" width={size ?? width ?? 24} height={size ?? height ?? 24} {...props}>
    <path d="M2 0C0.896875 0 0 0.896875 0 2V3H18V2C18 0.896875 17.1031 0 16 0H2ZM18 6H0V12C0 13.1031 0.896875 14 2 14H16C17.1031 14 18 13.1031 18 12V6ZM3.5 10H5.5C5.775 10 6 10.225 6 10.5C6 10.775 5.775 11 5.5 11H3.5C3.225 11 3 10.775 3 10.5C3 10.225 3.225 10 3.5 10ZM7 10.5C7 10.225 7.225 10 7.5 10H11.5C11.775 10 12 10.225 12 10.5C12 10.775 11.775 11 11.5 11H7.5C7.225 11 7 10.775 7 10.5Z" fill={color}/>
    </svg>
  );
}

export default CreditCard;
