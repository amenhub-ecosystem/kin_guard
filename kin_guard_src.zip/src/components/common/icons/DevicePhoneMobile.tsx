import * as React from "react";

type Props = React.SVGProps<SVGSVGElement> & { size?: number | string; color?: string };

export function DevicePhoneMobile({ size, width, height, color = "#003665", ...props }: Props) {
  return (
    <svg viewBox="0 0 11 16" fill="none" xmlns="http://www.w3.org/2000/svg" width={size ?? width ?? 24} height={size ?? height ?? 24} {...props}>
    <path d="M0 2C0 0.896875 0.896875 0 2 0H9C10.1031 0 11 0.896875 11 2V14C11 15.1031 10.1031 16 9 16H2C0.896875 16 0 15.1031 0 14V2ZM6.5 14C6.5 13.7348 6.39464 13.4804 6.20711 13.2929C6.01957 13.1054 5.76522 13 5.5 13C5.23478 13 4.98043 13.1054 4.79289 13.2929C4.60536 13.4804 4.5 13.7348 4.5 14C4.5 14.2652 4.60536 14.5196 4.79289 14.7071C4.98043 14.8946 5.23478 15 5.5 15C5.76522 15 6.01957 14.8946 6.20711 14.7071C6.39464 14.5196 6.5 14.2652 6.5 14ZM9 2H2V12H9V2Z" fill={color}/>
    </svg>
  );
}

export default DevicePhoneMobile;
