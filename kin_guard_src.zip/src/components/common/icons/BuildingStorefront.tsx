import * as React from "react";

type Props = React.SVGProps<SVGSVGElement> & { size?: number | string; color?: string };

export function BuildingStorefront({ size, width, height, color = "#00796B", ...props }: Props) {
  return (
    <svg viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg" width={size ?? width ?? 24} height={size ?? height ?? 24} {...props}>
    <path d="M6 1.5C6 0.671875 6.67188 0 7.5 0H12.5C13.3281 0 14 0.671875 14 1.5V16H11.5V13.5C11.5 12.6719 10.8281 12 10 12C9.17188 12 8.5 12.6719 8.5 13.5V16H6V1.5ZM1.5 3H5V16H1.5C0.671875 16 0 15.3281 0 14.5V10H2.5C2.775 10 3 9.775 3 9.5C3 9.225 2.775 9 2.5 9H0V7H2.5C2.775 7 3 6.775 3 6.5C3 6.225 2.775 6 2.5 6H0V4.5C0 3.67188 0.671875 3 1.5 3ZM18.5 3C19.3281 3 20 3.67188 20 4.5V6H17.5C17.225 6 17 6.225 17 6.5C17 6.775 17.225 7 17.5 7H20V9H17.5C17.225 9 17 9.225 17 9.5C17 9.775 17.225 10 17.5 10H20V14.5C20 15.3281 19.3281 16 18.5 16H15V3H18.5ZM9.75 2C9.475 2 9.25 2.225 9.25 2.5V3.25H8.5C8.225 3.25 8 3.475 8 3.75V4.25C8 4.525 8.225 4.75 8.5 4.75H9.25V5.5C9.25 5.775 9.475 6 9.75 6H10.25C10.525 6 10.75 5.775 10.75 5.5V4.75H11.5C11.775 4.75 12 4.525 12 4.25V3.75C12 3.475 11.775 3.25 11.5 3.25H10.75V2.5C10.75 2.225 10.525 2 10.25 2H9.75Z" fill={color}/>
    </svg>
  );
}

export default BuildingStorefront;
