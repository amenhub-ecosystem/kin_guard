import * as React from "react";

type Props = React.SVGProps<SVGSVGElement> & { size?: number | string; color?: string };

export function Plus({ size, width, height, color = "#FF6F61", ...props }: Props) {
  return (
    <svg viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" width={size ?? width ?? 24} height={size ?? height ?? 24} {...props}>
    <path d="M6.5625 0.875C6.5625 0.391016 6.17148 0 5.6875 0C5.20352 0 4.8125 0.391016 4.8125 0.875V4.8125H0.875C0.391016 4.8125 0 5.20352 0 5.6875C0 6.17148 0.391016 6.5625 0.875 6.5625H4.8125V10.5C4.8125 10.984 5.20352 11.375 5.6875 11.375C6.17148 11.375 6.5625 10.984 6.5625 10.5V6.5625H10.5C10.984 6.5625 11.375 6.17148 11.375 5.6875C11.375 5.20352 10.984 4.8125 10.5 4.8125H6.5625V0.875Z" fill={color}/>
    </svg>
  );
}

export default Plus;
