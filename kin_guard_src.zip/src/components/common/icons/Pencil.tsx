import * as React from "react";

type Props = React.SVGProps<SVGSVGElement> & { size?: number | string; color?: string };

export function Pencil({ size, width, height, color = "#9CA3AF", ...props }: Props) {
  return (
    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" width={size ?? width ?? 24} height={size ?? height ?? 24} {...props}>
    <path d="M11.3342 0.585938L9.82166 2.09844L13.8842 6.16094L15.3967 4.64844C16.1779 3.86719 16.1779 2.60156 15.3967 1.82031L14.1654 0.585938C13.3842 -0.195312 12.1185 -0.195312 11.3373 0.585938H11.3342ZM9.11541 2.80469L1.83103 10.0922C1.50603 10.4172 1.26853 10.8203 1.13728 11.2609L0.0310334 15.0203C-0.0470916 15.2859 0.0247834 15.5703 0.218533 15.7641C0.412283 15.9578 0.696658 16.0297 0.959158 15.9547L4.71853 14.8484C5.15916 14.7172 5.56228 14.4797 5.88728 14.1547L13.1779 6.86719L9.11541 2.80469Z" fill={color}/>
    </svg>
  );
}

export default Pencil;
